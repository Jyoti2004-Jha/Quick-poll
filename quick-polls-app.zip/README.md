# Quick Polls App

Full-stack Quick Polls application (backend + frontend).

## How to run locally

1. Start MongoDB locally (e.g. `mongod`).
2. Backend:
   ```
   cd backend
   npm install
   node server.js
   ```
3. Frontend:
   ```
   cd frontend
   npm install
   npm start
   ```

## Notes
- Use environment variables for production secrets.
- This is a minimal starter; you can improve validation, UI, and security.