const express = require('express');
const jwt = require('jsonwebtoken');
const Poll = require('../models/Poll');
const Vote = require('../models/Vote');
const User = require('../models/User');

const JWT_SECRET = process.env.JWT_SECRET || 'secret123';

function authMiddleware(req, res, next) {
  const header = req.headers['authorization'];
  if (!header) return res.status(401).json({ error: 'No token' });
  try {
    const decoded = jwt.verify(header, JWT_SECRET);
    req.userId = decoded.id;
    next();
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
}

module.exports = (io) => {
  const router = express.Router();

  // Create poll
  router.post('/', authMiddleware, async (req, res) => {
    try {
      const { question, options = [], isPublic = true } = req.body;
      if (!question || !options.length) return res.status(400).json({ error: 'Missing fields' });
      const poll = new Poll({
        question,
        options: options.map(o => ({ text: o })),
        createdBy: req.userId,
        isPublic
      });
      await poll.save();
      res.json(poll);
    } catch (err) {
      res.status(500).json({ error: 'Server error' });
    }
  });

  // Get all polls created by user
  router.get('/', authMiddleware, async (req, res) => {
    const polls = await Poll.find({ createdBy: req.userId }).sort({ createdAt: -1 });
    res.json(polls);
  });

  // Get poll by id (public allowed)
  router.get('/:id', async (req, res) => {
    const poll = await Poll.findById(req.params.id);
    if (!poll) return res.status(404).json({ error: 'Not found' });
    // compute results
    const votes = await Vote.find({ pollId: poll._id });
    const counts = poll.options.map((_, i) => votes.filter(v => v.optionIndex === i).length);
    res.json({ poll, results: counts });
  });

  // Vote
  router.post('/:id/vote', async (req, res) => {
    try {
      const pollId = req.params.id;
      const { optionIndex } = req.body;
      const token = req.headers['authorization'] || '';
      let userId = null;
      if (token) {
        try {
          const decoded = jwt.verify(token, JWT_SECRET);
          userId = decoded.id;
        } catch (err) { userId = null; }
      }
      const poll = await Poll.findById(pollId);
      if (!poll) return res.status(404).json({ error: 'Poll not found' });
      // Ensure one vote per user if logged in
      if (userId) {
        const existing = await Vote.findOne({ pollId, userId });
        if (existing) return res.status(400).json({ error: 'Already voted' });
      } else {
        // For public polls, we don't enforce unique votes for anonymous users
      }
      const vote = new Vote({ pollId, userId: userId || null, optionIndex });
      await vote.save();
      // Count updated results
      const votes = await Vote.find({ pollId });
      const counts = poll.options.map((_, i) => votes.filter(v => v.optionIndex === i).length);
      // Emit update to clients
      io.emit('voteUpdate', { pollId, results: counts });
      res.json({ message: 'Voted', results: counts });
    } catch (err) {
      res.status(500).json({ error: 'Server error' });
    }
  });

  return router;
};