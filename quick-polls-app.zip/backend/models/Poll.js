const mongoose = require('mongoose');
const pollSchema = new mongoose.Schema({
  question: { type: String, required: true },
  options: [{ text: String }],
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  isPublic: { type: Boolean, default: true }
}, { timestamps: true });
module.exports = mongoose.model('Poll', pollSchema);