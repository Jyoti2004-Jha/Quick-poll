const mongoose = require('mongoose');
const voteSchema = new mongoose.Schema({
  pollId: { type: mongoose.Schema.Types.ObjectId, ref: 'Poll', required: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  optionIndex: { type: Number, required: true }
}, { timestamps: true });
module.exports = mongoose.model('Vote', voteSchema);