# Backend - Quick Polls App

## Setup
1. Install dependencies:
   ```
   npm install
   ```
2. Start server (ensure MongoDB is running):
   ```
   node server.js
   ```
3. Environment variables:
   - MONGODB_URI: optional (defaults to mongodb://127.0.0.1:27017/quickpolls)
   - JWT_SECRET: optional

API endpoints:
- POST /auth/signup
- POST /auth/login
- POST /polls (auth)
- GET /polls (auth) - user's polls
- GET /polls/:id - poll + results
- POST /polls/:id/vote