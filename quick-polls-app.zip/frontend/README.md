# Frontend - Quick Polls App

## Setup
1. Install dependencies:
   ```
   npm install
   ```
2. Start:
   ```
   npm start
   ```
By default it expects backend at http://localhost:5000. You can set REACT_APP_API_URL environment variable.