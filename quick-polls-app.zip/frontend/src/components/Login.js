import React, { useState } from 'react';
import API from '../api';
export default function Login() {
  const [form, setForm] = useState({ email:'', password:'' });
  const submit = async (e) => {
    e.preventDefault();
    try {
      const res = await API.post('/auth/login', form);
      localStorage.setItem('token', res.data.token);
      window.location.href = '/create';
    } catch (err) {
      alert(err.response?.data?.error || 'Error');
    }
  };
  return (
    <form onSubmit={submit}>
      <h3>Login</h3>
      <input placeholder="Email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} /><br/>
      <input type="password" placeholder="Password" value={form.password} onChange={e=>setForm({...form, password:e.target.value})} /><br/>
      <button type="submit">Login</button>
    </form>
  );
}