import React, { useEffect, useState } from 'react';
import API from '../api';
import { Link } from 'react-router-dom';
export default function PollList() {
  const [polls, setPolls] = useState([]);
  useEffect(()=> {
    API.get('/polls').then(res => setPolls(res.data)).catch(()=>alert('Login required'));
  }, []);
  return (
    <div>
      <h3>My Polls</h3>
      {polls.length===0 && <p>No polls yet</p>}
      {polls.map(p => (
        <div key={p._id} style={{border:'1px solid #ddd', padding:8, margin:8}}>
          <div><strong>{p.question}</strong></div>
          <Link to={`/poll/${p._id}`}>Open</Link>
        </div>
      ))}
    </div>
  );
}