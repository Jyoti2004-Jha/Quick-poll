import React, { useState } from 'react';
import API from '../api';
export default function CreatePoll() {
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState(['','','','']);
  const submit = async (e) => {
    e.preventDefault();
    try {
      const filtered = options.filter(o=>o.trim()!=='');
      await API.post('/polls', { question, options: filtered, isPublic: true });
      alert('Poll created');
      window.location.href = '/mypolls';
    } catch (err) {
      alert(err.response?.data?.error || 'Error');
    }
  };
  return (
    <form onSubmit={submit}>
      <h3>Create Poll</h3>
      <input placeholder="Question" value={question} onChange={e=>setQuestion(e.target.value)} /><br/>
      {options.map((o, i) => (
        <input key={i} placeholder={`Option ${i+1}`} value={o} onChange={e=>{ const copy=[...options]; copy[i]=e.target.value; setOptions(copy); }} /><br/>
      ))}
      <button type="submit">Create</button>
    </form>
  );
}