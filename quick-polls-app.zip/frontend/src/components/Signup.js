import React, { useState } from 'react';
import API from '../api';
export default function Signup() {
  const [form, setForm] = useState({ name:'', email:'', password:'' });
  const submit = async (e) => {
    e.preventDefault();
    try {
      await API.post('/auth/signup', form);
      alert('Signup successful. Please login.');
      window.location.href = '/login';
    } catch (err) {
      alert(err.response?.data?.error || 'Error');
    }
  };
  return (
    <form onSubmit={submit}>
      <h3>Signup</h3>
      <input placeholder="Name" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} /><br/>
      <input placeholder="Email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} /><br/>
      <input type="password" placeholder="Password" value={form.password} onChange={e=>setForm({...form, password:e.target.value})} /><br/>
      <button type="submit">Signup</button>
    </form>
  );
}