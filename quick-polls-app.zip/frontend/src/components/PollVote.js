import React, { useEffect, useState } from 'react';
import API from '../api';
import { useParams } from 'react-router-dom';
import { io } from 'socket.io-client';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const socket = io(process.env.REACT_APP_API_URL || 'http://localhost:5000');

export default function PollVote() {
  const { id } = useParams();
  const [poll, setPoll] = useState(null);
  const [results, setResults] = useState([]);

  useEffect(()=> {
    API.get(`/polls/${id}`).then(res => {
      setPoll(res.data.poll);
      setResults(res.data.results || res.data.poll.options.map(()=>0));
    }).catch(()=>alert('Error fetching poll'));

    socket.on('voteUpdate', data => {
      if (data.pollId === id) {
        setResults(data.results);
      }
    });

    return () => { socket.off('voteUpdate'); };
  }, [id]);

  const vote = async (index) => {
    try {
      await API.post(`/polls/${id}/vote`, { optionIndex: index });
    } catch (err) {
      alert(err.response?.data?.error || 'Error voting');
    }
  };

  if (!poll) return <p>Loading...</p>;
  const chartData = poll.options.map((o,i)=>({ name: o.text, votes: results[i] || 0 }));
  return (
    <div>
      <h3>{poll.question}</h3>
      {poll.options.map((o,i)=>(
        <button key={i} style={{display:'block', margin:'6px 0'}} onClick={()=>vote(i)}>{o.text}</button>
      ))}
      <div style={{width:'100%', height:300}}>
        <ResponsiveContainer>
          <BarChart data={chartData}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="votes" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}