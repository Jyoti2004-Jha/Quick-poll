import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Signup from './components/Signup';
import Login from './components/Login';
import CreatePoll from './components/CreatePoll';
import PollList from './components/PollList';
import PollVote from './components/PollVote';

function Nav() {
  const token = localStorage.getItem('token');
  return (
    <nav style={{padding:10, borderBottom:'1px solid #ccc'}}>
      <Link to="/" style={{marginRight:10}}>Home</Link>
      {token ? (
        <>
          <Link to="/create" style={{marginRight:10}}>Create Poll</Link>
          <Link to="/mypolls" style={{marginRight:10}}>My Polls</Link>
          <button onClick={() => { localStorage.removeItem('token'); window.location.href = '/'; }}>Logout</button>
        </>
      ) : (
        <>
          <Link to="/login" style={{marginRight:10}}>Login</Link>
          <Link to="/signup">Signup</Link>
        </>
      )}
    </nav>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Nav />
      <div style={{padding:20}}>
        <Routes>
          <Route path="/" element={<div><h2>Welcome to Quick Polls</h2><p>Create quick polls and see live results.</p></div>} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/login" element={<Login />} />
          <Route path="/create" element={<CreatePoll />} />
          <Route path="/mypolls" element={<PollList />} />
          <Route path="/poll/:id" element={<PollVote />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}